/***
 * asset api
 */
const fs = require("fs");
const path = require("path");
const database = require("../data/database"), DB = new database();
const folder = `${__dirname}/../../${process.env.ASSET_FOLDER}`;
const fUtil = require("../fileUtil");
const https = require("https");

// studio.swf's FontManager.CUSTOM_FONT_ID_REGEXP is /^ugc\.([0-9]+)$/ - digits only.
// A hex id like "58f3d25" fails that match everywhere it's checked (loadFont(),
// isUserFont(), the library thumbnail renderers), which is what sends custom font
// loads down the wrong "built-in font" code path. Fonts specifically need a
// numeric-only id. Scoped to fonts only, since fUtil.generateId()'s hex format may
// be relied on elsewhere for chars/bg/sound/prop/movie assets we can't see here.
function generateNumericId() {
	return `${Date.now()}${Math.floor(Math.random() * 900) + 100}`;
}

module.exports = {
	delete(aId, type) {
		let type2;
		if (!type) type2 = "assets";
		else type == "folder" ? type2 = "folders" : type2 = type;
		// remove info from database
		const db = DB.get();
		const met = db[type2].find(i => i.id == aId);
		let folder2;
		for (const stuff in met) if (stuff == "folder") folder2 = met.folder;
		const index = db[type2].findIndex(i => i.id == aId);
		db[type2].splice(index, 1);
		DB.save(db);
		// find file by id and delete it
		if (type == 'folder') {
			try {
				fs.rmdirSync(`${folder}/folders/${aId}`);
			} catch (e) {
				const files = [];
				const db = DB.get();
				fs.readdirSync(`${folder}/folders/${aId}`).forEach(file => {
					fs.unlinkSync(`${folder}/folders/${aId}/${file}`)
					const index = db.assets.findIndex(i => i.id == file.split(".")[0]);
					db.assets.splice(index, 1);
					files.push(file);
				});
				DB.save(db);
				fs.rmdirSync(`${folder}/folders/${aId}`);
				return files;
			}
		} else fs.readdirSync(folder).forEach(file => {
			if (file.includes(aId)) {
				if (fs.existsSync(`${folder}/${file}`)) fs.unlinkSync(`${folder}/${file}`);
				else if (fs.existsSync(`${folder}/folders/${folder2}/${file}`)) fs.unlinkSync(`${folder}/folders/${folder2}/${file}`);
			}
		});
	},
	list(type, subtype = null, tId = null) { // very simple thanks to the database
		const db = DB.get();
		const table = [];
		let aList = db.assets.filter(i => i.type == type);
		// more filters
		if (subtype) aList = aList.filter(i => i.subtype == subtype);
		if (tId) aList = aList.filter(i => i.themeId == tId);
		for (const stuff of aList) if (!stuff.folder) table.unshift(stuff);
		if (type == "char") return aList;
		else return table;
	},
	listInFolder(foldername) { // very simple thanks to the database
		const db = DB.get();
		let aList = db.assets.filter(i => i.folder == foldername);
		return aList.filter(i => i.type == "prop");
	},
	getFileCount(foldername) { 
		let count = 0;
		fs.readdirSync(`${folder}/folders/${foldername}`).forEach(() => {
			count++
		});
		return count;
	},
	/**
	 * Saves the asset and its metadata.
	 * @param {fs.ReadStream} readStream 
	 * @param {object} meta 
	 * @returns {string}
	 */
	saveStream(readStream, meta) {
    // Save asset info
    const aId = `${fUtil.generateId()}.${meta.ext}`;
    const db = DB.get();

    let newMeta = {
        id: aId,
        tags: ""
    };

    // Special handling for videos
    if (fileTypes.video[meta.ext]) {
        meta = {
            ...meta,
            id: `${aId}.flv`,
            enc_asset_id: `${aId}.flv`
        };
    }

    // Redirect handling
    if (f.redirect && !fileTypes.prop[meta.ext]) {
        meta.redirect = f.redirect;
    }

    delete meta.ext;

    Object.assign(newMeta, meta);

    db.assets.unshift(newMeta);
    DB.save(db);

    // Save the file
    const writeStream = fs.createWriteStream(
        path.join(folder, aId)
    );

    readStream.resume();
    readStream.pipe(writeStream);

    return aId;
},
	createBubbleThumb(fontId) {
    const theme = ThemeManager.instance.userTheme;

    const bubbleThumb = new BubbleThumb();

    const fontModel = FontManager
        .getFontManager()
        .getFontModelByFontId(fontId);

    bubbleThumb.id = fontModel.value;
    bubbleThumb.aid = fontModel.id;
    bubbleThumb.encAssetId = fontModel.encAssetId;
    bubbleThumb.tags = fontModel.tags;
    bubbleThumb.name = fontModel.label;
    bubbleThumb.enable = true;
    bubbleThumb.editable = this.isAssetEditable;

    bubbleThumb.setFileName(fontModel.id + ".swf");
    bubbleThumb.imageData = bubbleThumb.getDefaultBubbleBody(fontModel.value);

    bubbleThumb.type = "BLANK";
    bubbleThumb.theme = theme;

    theme.addThumb(bubbleThumb);

    return bubbleThumb;
},
	listFolders() {
		return DB.get().folders;
	},
	load(aId) { // look for match in folder
			const match = this.exists(aId);
			return match ? fs.readFileSync(path.join(folder, match)) : null;
	},
	exists(aId) { // look for match in folder
			const match = fs.readdirSync(folder)
				.find(file => file.includes(aId));
			return match || false;
	},	
	meta(aId) {
    const met = DB.get().assets.find(i =>
        i.id === aId ||
        i.id === `${aId}.flv` ||
        i.enc_asset_id === aId
    );

    if (!met) {
        console.error("Asset metadata doesn't exist! Asset id:", aId);
        return { status: "error", msg: "invalid_asset" };
    }

    return {
        status: "ok",
        data: met
    	};
	},
	save(buf, meta) {
	// save asset info
	const aId = meta.type === "font" ? generateNumericId() : fUtil.generateId();
	const db = DB.get();

	const asset = { // base info, can be modified by the user later
		id: aId,
		width: meta.width,
		height: meta.height,
		enc_asset_id: aId,
		themeId: meta.tId,
		type: meta.type,
		subtype: meta.subtype,
		title: meta.title,
		published: "",
		share: {
			type: "none"
		},
		tags: "",
		duration: meta.duration,
		file: `${aId}.${meta.ext}`,
		signature: ""
	};

	// Video-specific FLV handling
	if (meta.type === "video") {
		const asset = {
		enc_asset_id: `${aId}.flv`,
		id: `${aId}.flv`
		}
	}

	db.assets.unshift(asset);
	DB.save(db);

	// save the original file
	fs.writeFileSync(`${folder}/${aId}.${meta.ext}`, buf);

	// save encoded FLV copy for videos
	if (meta.type === "video") {
		fs.writeFileSync(`${folder}/${aId}.flv`, buf);
	}

	meta.file = `${aId}.${meta.ext}`;
	meta.enc_asset_id = asset.enc_asset_id;
	meta.id = aId;

	if (meta.type == "sound" || meta.type == "video") {
		fs.writeFileSync(
			`${folder}/${aId}.png`,
			fs.readFileSync(`./wrapper/pages/img/importer/${meta.type}.png`)
		);
	}

	return aId;
	},
	update(newInf) {
		// set new info and save
		const db = DB.get();
		const met = db.assets.find(i => i.id == newInf.movieId || newInf.id ? newInf.id.includes(".") ? newInf.id.split(".")[0] : newInf.id : newInf.assetId ? newInf.assetId.includes(".") ? newInf.assetId.split(".")[0] : newInf.assetId : '');
		for (const stuff in newInf) if (stuff != "updatingFromHTML") met[stuff] = newInf[stuff];
		if (newInf.updatingFromHTML && met.share) {
			met.share = {
				type: newInf.share
			}
		}
		console.log(newInf);
		if ((newInf.tags && newInf.tags.includes("_public")) || (newInf.updatingFromHTML && newInf.share == "team")) return {
			error: true,
			msg: "In order to upload your asset as a public one, you need to request one of the Vyond Remastered Developers to help you get your asset public."
		};
		else {
			DB.save(db);
			return {
				ok: true
			};
		}
	},
	updateFolder(newInf) {
		// set new info and save
		const db = DB.get();
		const met = db.folders.find(i => i.id == newInf.id);
		if (newInf.updatingFromHTML) met.name = newInf.title;
		else for (const stuff in newInf) met[stuff] = newInf[stuff];
		DB.save(db);
		return true;
	}
};
